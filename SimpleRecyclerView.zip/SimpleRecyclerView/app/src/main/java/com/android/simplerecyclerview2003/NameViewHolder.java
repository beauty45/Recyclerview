package com.android.simplerecyclerview2003;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NameViewHolder extends RecyclerView.ViewHolder {

    TextView nameTextView;

    public NameViewHolder(@NonNull View itemView) {
        super(itemView);


        nameTextView = itemView.findViewById(R.id.nameTv);



    }
}

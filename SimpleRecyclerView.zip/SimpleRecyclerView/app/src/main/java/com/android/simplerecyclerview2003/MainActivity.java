package com.android.simplerecyclerview2003;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> nameList;

    RecyclerView nameRecycler;
    NameAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameRecycler = findViewById(R.id.nameRecycler);

        nameList = new ArrayList<>();

        nameList.add("Masum");
        nameList.add("Nejam");
        nameList.add("Faruk");
        nameList.add("Nahid");
        nameList.add("RAFi");
        nameList.add("Affif");
        nameList.add("Autosi");
        nameList.add("Beauty");
        nameList.add("Jaber");
        nameList.add("Masud");
        nameList.add("Jui");
        nameList.add("Mamun");
        nameList.add("Murong");
        nameList.add("Rownak");
        nameList.add("Rudra");
        nameList.add("Mariya");
        nameList.add("Sumon");
        nameList.add("Tanmoy");

        adapter = new NameAdapter(MainActivity.this, nameList);

        nameRecycler.setAdapter(adapter);


    }
}